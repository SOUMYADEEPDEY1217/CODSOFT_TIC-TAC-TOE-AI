# Tic-Tac-Toe AI

An unbeatable Tic-Tac-Toe game implemented with the Minimax algorithm.

## Features
- Play as "X", AI plays as "O"
- AI uses the Minimax algorithm to make optimal moves
- Simple terminal interface

## How to Run
```bash
python tic_tac_toe_ai.py
```

Follow on-screen prompts to play.

## Requirements
- Python 3.x
(No additional libraries required)
